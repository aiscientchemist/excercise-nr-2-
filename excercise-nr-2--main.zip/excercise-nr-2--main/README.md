# excercise-nr-2-
This is a quick excercise to improve my skills in python ;)
